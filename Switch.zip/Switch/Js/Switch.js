const resultado = prompt("Escolha uma alternativa: \nA) Aula 1 \nB) Aula 2 \nC) Aula 3 \nD)Aula 4 \nE) Aula 5 \nF) Aula 6")

switch (resultado) {
  case "a":
    alert("O resultado é 'Aula 1'")
    break
  case "b":
    alert("O resultado é 'Aula 2'")
    break
  case "c":
    alert("O resultado é 'Aula 3'")
    break
  case "D":
    alert("O resultado é 'Aula 4'")
    break
  case "E":
    alert("O resultado é 'Aula 5'")
    break
  case "F":
    alert("O resultado é 'Aula 6'")
    break
  default:
    alert("Finalizando...")
}