let indice = 1

alert("Iniciando o For")

for (indice = 1; indice <=5; indice++) {
    alert("Indice = " + indice)
}

alert("Finalizando o For")